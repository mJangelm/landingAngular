export interface Iproyecto {
    id: number,
    titulo: string,
    img: string,
    tecnologias: string,
    descripcion: string,
    url: string,
    urlYoutube?: string;
}
