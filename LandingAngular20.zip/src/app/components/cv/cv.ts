import { Component } from '@angular/core';

@Component({
  selector: 'app-cv',
  standalone:true,
  imports: [],
  templateUrl: './cv.html',
  styleUrl: './cv.css'
})
export class Cv {

}
