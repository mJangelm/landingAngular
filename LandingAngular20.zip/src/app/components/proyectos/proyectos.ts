import { Component } from '@angular/core';
import { Iproyecto } from '../../interfaces/iproyecto';
import { ProyectoCardComponent } from '../proyecto-card/proyecto-card.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-proyectos',
  standalone:true,
  imports: [ProyectoCardComponent, CommonModule],
  templateUrl: './proyectos.html',
  styleUrl: './proyectos.css'
})
export class Proyectos {

  proyectos: Iproyecto[] = [
    {
      id: 1,
      titulo: 'Open Talent',
      img: 'assets/img/proyectos/openTalent.png',
      tecnologias: 'Angular, MySql, Figma, Spring Boot',
      descripcion: 'Aplicación grupal creada para la búsqueda de empresas de prácticas.',
      url: 'https://mi-portfolio.com',
      urlYoutube: 'https://www.youtube.com/watch?v=hIITd6ICxjs'
    },
    {
      id: 2,
      titulo: 'App de Tareas',
      img: 'assets/imgs/tareas.png',
      tecnologias: 'React, Node.js',
      descripcion: 'Aplicación para gestionar tareas diarias',
      url: 'https://appdetareas.com'
    }
  ];
  proyecto! : Iproyecto;

}
