import { Component } from '@angular/core';

@Component({
  selector: 'app-south-logo',
  imports: [],
  standalone:true,
  templateUrl: './south-logo.html',
  styleUrl: './south-logo.css'
})
export class SouthLogo {

}
