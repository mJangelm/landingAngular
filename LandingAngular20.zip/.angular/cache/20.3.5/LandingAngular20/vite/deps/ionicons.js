import {
  addIcons,
  setAssetPath
} from "./chunk-NMQOMRJI.js";
import "./chunk-QHQP2P2Z.js";
export {
  addIcons,
  setAssetPath
};
